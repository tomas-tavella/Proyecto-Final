Key to Database files

Jobname = TEX024

TEX024_TMDSCNCD28335PGFr1_0_current.PCB 		Innoveda database (binary)
TEX024_TMDSCNCD28335PGFr1_0_current.ASC		Innoveda database (ASCII)
TEX024_TMDSCNCD28335PGFr1_0_current.dxf		DXF of entire database
TEX024_TMDSCNCD28335PGFr1_0_current.net		Netlist derived from board
TEX024_TMDSCNCD28335PGFr1_0_current.ntl		Net length report
